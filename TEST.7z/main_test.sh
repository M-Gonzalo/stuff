rm $1.*

bash preprocesors $1 | xargs -P $2 -0 bash -c
bash compresors $1 | xargs -P $2 -0 bash -c

du -b $1*.ppmd $1*.7zf | sort -n
rm $1.*