rm $1.* $1_log

echo Preprocesing...
bash preprocesors $1 | xargs -P $2 -I '{}' bash -c '{}' 1>/dev/null 2>/dev/null
echo Compresing...
bash compresors $1 | xargs -P $2 -I '{}' bash -c '{}' 1>/dev/null 2>/dev/null

du -b $1*.ppmd $1*.7zf | sort -n >$1_log && cat $1_log
rm $1.*